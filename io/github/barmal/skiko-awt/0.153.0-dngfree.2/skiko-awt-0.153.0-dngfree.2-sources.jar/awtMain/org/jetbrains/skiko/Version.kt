package org.jetbrains.skiko
object Version {
    val skiko = "0.153.0-dngfree.2"
    val skia = "m153-e63f5d6129"
}